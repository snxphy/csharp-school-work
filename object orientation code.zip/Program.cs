﻿using System;

namespace MainProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            //new for class Book
            //Console.WriteLine("----------------------------------------------------");
            //Book book = new Book("Planet Of The Trees", "NOT Aidan", "1928304850", 2021);
            //book.PrintDetails();
            //Console.WriteLine("----------------------------------------------------");
            //Book book2 = new Book("Planet Of The Trees: The Treepire Strikes Back", "NOT Aidan", "1928304863", 2025);
            //book2.PrintDetails();
            Console.WriteLine("----------------------------------------------------");
            //new for class Customer
            Customer customer = new Customer("Juan",040);
            customer.OutputDetails();
            Console.WriteLine("----------------------------------------------------");
            Librarian librarian = new Librarian("Sasuke");
            librarian.OutputDetail();
            DataBase database = new DataBase();
            Book book;
            book = librarian.CreateBook("Planet Of The Trees", "NOT Aidan", "1928304850", 2012, "\n----------------------------------------------------\n");
            database.AddBook(book);
            book = librarian.CreateBook("Planet Of The Trees: The Treepire Strikes Back", "NOT Aidan", "1928304863", 2016,"\n----------------------------------------------------\n");
            database.AddBook(book);
            book = librarian.CreateBook("Planet Of The Trees: Return Of The Treedi", "NOT Aidan", "1929204851", 2020,"\n----------------------------------------------------\n");
            database.AddBook(book);
            Console.WriteLine("----------------------------------------------------");
            database.OutputData();
            
        }
    }
}