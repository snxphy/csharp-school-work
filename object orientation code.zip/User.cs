using System;
using System.Collections.Generic;
using System.Text;

namespace MainProgram
{
    class User
    {   
        //string
        protected string _name;
        protected int _id;

        //public the class
        public User() { }
        
        //public
        public virtual void OutputDetails()
        {
            Console.WriteLine("No Record Found");
        }
    }
}
