using System;
using System.Collections.Generic;
using System.Text;

namespace MainProgram
{
    class Customer:User
    {
        private int _accountNumber;
        public Customer(string name, int accountNumber)
        {
            _name = name;
            _accountNumber = accountNumber;
            _id = new Random().Next(1,1000);
        }

        public Customer() { }

        public override void OutputDetails()
        {
            Console.WriteLine($"Name: {_name}"+$"\nID: {_id}"+$"\nAccount Number: {_accountNumber}");
        }

        //TODO - Method of type string to search database
        
    }
}