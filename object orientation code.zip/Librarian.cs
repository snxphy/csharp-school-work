using System;
using System.Collections.Generic;
using System.Text;

namespace MainProgram
{
    class Librarian:User
    {
        private string _password;

        public Librarian(string name)
        {
            _name = name;
            _password = "911";
            _id = new Random().Next(1,1000);
        }

        public void OutputDetail()
        {
            Console.WriteLine($"Name: {_name}"+$"\nID: {_id}"+$"\nPassword: {_password}");
        }

        //TODO - Method of type Book to add Books to database
        public Book CreateBook(string title, string author, string isbn, int yearPublished, string newline)
        {
            Book book = new Book(title, author, isbn, yearPublished, newline);
            return book;
        }

    }
}