using System;
using System.Collections.Generic;
using System.Text;

namespace MainProgram
{
    class DataBase
    {
        //TODO - List of Book type
        private List<Book> bookInventory = new List<Book>();

        //TODO - Method to add Book to list
        public void AddBook(Book book)
        {
            bookInventory.Add(book);
        }
        
        public void OutputData()
        {
            foreach (Book book in bookInventory)
            {
                book.PrintDetails();
            }
        }
        //TODO - Query DataBase

    }
}