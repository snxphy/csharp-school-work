using System;
using System.Collections.Generic;
using System.Text;

namespace MainProgram
{
    class Book
    {   
        //inaccessible information in class
        private string _title;
        private string _author;
        private string _isbn;
        private int _yearPublished;

        private string _newline;

        //public access for class Book for string and int variables
        public Book(string title, string author, string isbn, int yearPublished, string newline)
        {
            _title = title;
            _author = author;
            _isbn = isbn;
            _yearPublished = yearPublished;
            _newline = newline;
        }
        public void PrintDetails()
        {
            Console.WriteLine($"Book Title: {_title}" + $"\nBook Author: {_author}" + $"\nBook ISBN: {_isbn}" + $"\nYear Published: {_yearPublished}"+$"{_newline}");

        }
    }
}